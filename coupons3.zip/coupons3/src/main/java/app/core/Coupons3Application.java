package app.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Coupons3Application {

	public static void main(String[] args) {
		SpringApplication.run(Coupons3Application.class, args);
	}

}
