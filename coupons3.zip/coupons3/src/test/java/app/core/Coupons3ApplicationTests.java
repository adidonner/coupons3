package app.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Coupons3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
