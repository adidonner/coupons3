import "./About.css";

function About(): JSX.Element {
    return (
        <div className="About">
            <h2>////</h2>
			<h2>This website is a development practice </h2>
			<h2>guided by Bakshi Eldar </h2>
			<h2>made by Adi Donner in his studies at  </h2>
			<h2>John Bryce &copy; course 153 </h2>
            <img src="https://scontent.ftlv6-1.fna.fbcdn.net/v/t1.6435-9/48393365_1924861360884733_7831172702982373376_n.png?_nc_cat=103&ccb=1-7&_nc_sid=09cbfe&_nc_ohc=5WDwOAEQdHoAX_2Dt92&_nc_ht=scontent.ftlv6-1.fna&oh=00_AfCs1aYcE7znxeJj59i5Afq-j4pGgSiaQdGowNwZ5fgnUQ&oe=646D7A12"
            alt="JB"
            height={70}
            />
        </div>
    );
}

export default About;
