import ClientType from "./ClientType";

class CredentialsModel {
	public clientType?: ClientType;
    public email?: string;
    public password?: string;
}

export default CredentialsModel;
