enum ClientType {
	CUSTOMER = "CUSTOMER",
    COMPANY = "COMPANY",
    ADMINISTRATION = "ADMINISTRATION"
}

export default ClientType;
