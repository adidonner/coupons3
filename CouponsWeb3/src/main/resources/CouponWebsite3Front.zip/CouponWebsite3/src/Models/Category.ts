enum Category {
    SPORTS = "SPORTS",
    CLOTHINGS = "CLOTHINGS", 
    ELECTRICITY = "ELECTRICITY",
    CAMPING = "CAMPING",
    FOOD = "FOOD",
    RESTAURANTS = "RESTAURANTS",
    VACATIONS = "VACATIONS"
}

export default Category;
