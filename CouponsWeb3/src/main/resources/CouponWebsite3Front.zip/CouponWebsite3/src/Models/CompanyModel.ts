import ClientType from "./ClientType";
import CouponModel from "./CouponModel";

class CompanyModel {
	public id: number;
    public email: string;
    public password: string;
    public name: string;
    public clientType: ClientType;
    public logoImage: string;
	



    public constructor(id: number, companyId: number, email: string, password: string, name: string, clientType: ClientType, logoImage?: string) {
            this.id = id;
            this.email = email;
            this.password = password;
            this.name = name;
            this.clientType = clientType;
            this.logoImage = logoImage;
    }
    
}

export default CompanyModel;
